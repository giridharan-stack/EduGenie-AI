# EduGenie AI - 8 Phase Project Submission

Project: EduGenie AI
Team ID: 6ab7396968850e4f5dcde538
Team Lead: Giridharan.S
Team Member 1: V Dilli babu
Team Member 2: A Vigneshwaran
Class: BSc CS 2 year

This repository is organized according to the required 8 project phases.

1. Brainstorming & Ideation
2. Requirement Analysis
3. Project Design Phase
4. Project Planning Phase
5. Project Development Phase
6. Project Testing Phase
7. Project Documentation Phase
8. Project Demonstration Phase

Technology: HTML, CSS, JavaScript, Python, FastAPI, Google Gemini API.
AI model used in the running backend: gemini-3.5-flash-lite.
